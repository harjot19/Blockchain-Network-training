const localStrategy = require('passport-local');
module.exports = function(passport){

}