(document).ready(() => {
  


    console.log("inscript");
    $("#tbutton").on('click',() => {
        // let name = "harry";

        // var jsonData = {
        //     fullName : name
        // }
        // $.ajax({
        //     url:

        // });
        console.log('yeah button is working')
    })
})