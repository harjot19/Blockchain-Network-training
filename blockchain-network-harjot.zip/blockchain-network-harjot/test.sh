#!/bin/bash --  
#this is a comment

echo hello , learning shell script
source /home/harjot/Documents/blockchain-network/config.sh

#shell script variables
var1=hello
var2=shell

echo "$var1"
#it is same as $var1

#usinf config file varaiable
echo " $var1 $var3 $var4 "

#ifelse in shell scripting

a=10
b=20

if [ $a == $b ];
then
   echo "a is equal to b"
else
   echo "a is not equal to b"
fi


#if -elif

if [ $a == $b ]
then
	echo "a is  equal b"
elif [ $a -gt $b ]
then
	echo "a is gretre"
else 
	echo "exists"
fi

#################################################

#for loop
#counting from 3 to 20 skipping 2 values
for table in {3..20..2}
	do
		echo "table for 3 : $table"
done

#nested while

a=2
while [ $a -lt 2 ]
do
	b=$a
	while [ $b -ge 2 ]
	do
		echo "inside b loop"
	done
done

#####################################
#until loop
echo "until lop"
until [ ! $a -lt 10 ]
do
   echo $a
   a=`expr $a + 1`
done

###################################
#select
echo "###################################"
select DRINK in tea cofee water juice appe all none
do
   case $DRINK in
      tea|cofee|water|all) 
         echo "Go to canteen"
         ;;
      juice|appe)
         echo "Available at home"
      ;;
      none) 
         break 
      ;;
      *) echo "ERROR: Invalid selection" 
      ;;
   esac
done

#################################
#functions

echo "-n functions"

function add() {
	
	result=$(($1 + $2))
	echo "after edition $result"
}

###calling function
a=10
b=20
add 10  20



############################################
#swithc case
echo "switch case"

echo "enter switch case"

read state

case $state in 
	"hp")
		echo "HP"
	;;
	"pb")
		echo "Punjab"
	;;
	*)
		echo"wrong entry"
	;;
esac



#############################################
#arrays
var1=1
var2=2
var3=3

array[0]=$var1
array[1]=$var2
######
#first method to access all elemets at once

echo "first method ${array[*]}"

echo "$second method ${array[@]}"

##################################
#arrays 
myArray=("cat" "dog" "mouse" "frog")

for str in ${myArray[@]}; do
  echo $str
done

