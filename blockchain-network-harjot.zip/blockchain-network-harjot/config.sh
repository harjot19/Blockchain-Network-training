#this is config file

var3=config
var4=file
